from pipowl.semantic import SemanticOwl
from pipowl.light import LightOwl

print("Import OK")