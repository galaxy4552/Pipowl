from .core import SnowOwlShell
from .version import __version__

__all__ = ["SnowOwlShell", "__version__"]
