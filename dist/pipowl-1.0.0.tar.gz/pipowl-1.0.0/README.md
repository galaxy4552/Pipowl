# pipowl-shell

我打造了一個系統。
AI 說它很強。
但我心想：可是我只是一隻雪鴞啊。

# Quick Start

```python
from pipowl import SnowOwlShell

owl = SnowOwlShell()
print(owl.hello())